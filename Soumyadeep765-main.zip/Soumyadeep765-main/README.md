<div align="center">
  
# [![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Fira+Code&weight=600&size=30&pause=1000&color=3FA6E6&random=false&width=600&lines=Hi+%F0%9F%91%8B%2C+I'm+Soumyadeep765;A+Part+Time+Developer+from+India+%F0%9F%9A%80)](https://git.io/typing-svg)

<p align="center">
  <a href="https://github.com/Soumyadeep765?tab=followers">
    <img src="https://img.shields.io/github/followers/Soumyadeep765?label=Followers&logo=GitHub&style=for-the-badge" alt="GitHub Followers" />
  </a>
  <a href="https://github.com/Soumyadeep765">
    <img src="https://komarev.com/ghpvc/?username=Soumyadeep765&label=Profile%20views&color=0e75b6&style=for-the-badge" alt="Profile Views" />
  </a>
</p>

</div>

<div align="center">
  <img src="https://github-stats-alpha.vercel.app/api?username=Soumyadeep765&cc=000&tc=fff&ic=fff&bc=000" alt="Stats">
</div>

## 📊 GitHub Statistics

<p align="center">
  <img width="49%" src="https://github-readme-stats.vercel.app/api?username=Soumyadeep765&show_icons=true&theme=tokyonight&hide_border=true" />
  <img width="49%" src="https://github-readme-streak-stats.herokuapp.com/?user=Soumyadeep765&theme=tokyonight&hide_border=true" />
</p>

<div align="center">
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=Soumyadeep765&theme=tokyonight&hide_border=true&include_all_commits=false&count_private=false&layout=compact" alt="Top Languages" />
</div>

## 💻 Tech Stack

<div align="center">

![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E)
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
![MySQL](https://img.shields.io/badge/MySQL-005C84?style=for-the-badge&logo=mysql&logoColor=white)
![NodeJS](https://img.shields.io/badge/node.js-6DA55F?style=for-the-badge&logo=node.js&logoColor=white)
![Git](https://img.shields.io/badge/git-%23F05033.svg?style=for-the-badge&logo=git&logoColor=white)
![GitHub](https://img.shields.io/badge/github-%23121011.svg?style=for-the-badge&logo=github&logoColor=white)
![VS Code](https://img.shields.io/badge/Visual%20Studio%20Code-0078d7.svg?style=for-the-badge&logo=visual-studio-code&logoColor=white)

</div>

## 📈 Contribution Graph

<img src="https://github-readme-activity-graph.vercel.app/graph?username=Soumyadeep765&theme=react-dark&hide_border=true" width="100%"/>

## 🌟 GitHub Metrics

<p align="center">
  <img width="625em" src="https://github-profile-summary-cards.vercel.app/api/cards/profile-details?username=Soumyadeep765&theme=github_dark" />
</p>

<p align="center">
  <img width="300em" src="https://github-profile-summary-cards.vercel.app/api/cards/repos-per-language?username=Soumyadeep765&theme=github_dark" />
  <img width="300em" src="https://github-profile-summary-cards.vercel.app/api/cards/most-commit-language?username=Soumyadeep765&theme=github_dark" />
</p>

## 🤝 Connect With Me

<div align="center">
  
[![LinkedIn](https://img.shields.io/badge/LinkedIn-%230077B5.svg?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/soumyadeep-das-495339254?trk=contact-info)
[![Twitter](https://img.shields.io/badge/Twitter-%231DA1F2.svg?style=for-the-badge&logo=Twitter&logoColor=white)](https://x.com/soumyadeep765)
[![Gmail](https://img.shields.io/badge/Gmail-%23EA4335.svg?style=for-the-badge&logo=gmail&logoColor=white)](mailto:soumyadeeppdas765@gmail.com)
[![Telegram](https://img.shields.io/badge/Telegram-%23000000.svg?style=for-the-badge&logo=firefox&logoColor=white)](https://t.me/soumyadeepdas765)

</div>

## 💭 Random Dev Quote
<div align="center">
  
![](https://quotes-github-readme.vercel.app/api?type=horizontal&theme=tokyonight)

</div>

---

<div align="center">


### ⚡ Fun Fact
*"There are around 700 different programming languages!, but i don't know anything 🙂"*

</div>

---


### Show some ❤️ by starring repositories you find interesting!

</div>
